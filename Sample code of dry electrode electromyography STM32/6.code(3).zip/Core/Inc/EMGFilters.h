#ifndef _EMGFILTERS_H
#define _EMGFILTERS_H

#define true 1
#define false 0

typedef enum  { NOTCH_FREQ_50HZ = 50, NOTCH_FREQ_60HZ = 60 }NOTCH_FREQUENCY;
typedef enum  { SAMPLE_FREQ_500HZ = 500, SAMPLE_FREQ_1000HZ = 1000 }SAMPLE_FREQUENCY;

void LPF_init(int sampleFreq) ;
float LPF_update(float input) ;

void HPF_init(int sampleFreq) ;
float HPF_update(float HPF_input) ;

void AHF_init(int sampleFreq, int humFreq) ;
float AHF_update(float AHF_input) ;

int EMGFilters_update(int EMGFilters_inputValue);
void EMGFilters_init(SAMPLE_FREQUENCY sampleFreq,
                     NOTCH_FREQUENCY  notchFreq,
                     int             enableNotchFilter,
                     int             enableLowpassFilter,
                     int             enableHighpassFilter);
										 
#endif

/***/

#include "EMGFilters.h"

// ��ͨ�˲������ݺ���ϵ��
// coef[sampleFreqInd][order]
static float lpf_numerator_coef[2][3]   = {{0.3913, 0.7827, 0.3913},
                                          {0.1311, 0.2622, 0.1311}};
static float lpf_denominator_coef[2][3] = {{1.0000, 0.3695, 0.1958},
                                          {1.0000, -0.7478, 0.2722}};
// ��ͨ�˲������ݺ���ϵ��
static float hpf_numerator_coef[2][3]   = {{0.8371, -1.6742, 0.8371},
                                          {0.9150, -1.8299, 0.9150}};
static float hpf_denominator_coef[2][3] = {{1.0000, -1.6475, 0.7009},
                                           {1.0000, -1.8227, 0.8372}};
// �ݲ����Ĵ��ݺ���ϵ��
// coef[sampleFreqInd][order] for 50Hz
static float ahf_numerator_coef_50Hz[2][6] = {
    {0.9522, -1.5407, 0.9522, 0.8158, -0.8045, 0.0855},
    {0.5869, -1.1146, 0.5869, 1.0499, -2.0000, 1.0499}};
static float ahf_denominator_coef_50Hz[2][6] = {
    {1.0000, -1.5395, 0.9056, 1.0000 - 1.1187, 0.3129},
    {1.0000, -1.8844, 0.9893, 1.0000, -1.8991, 0.9892}};
static float ahf_output_gain_coef_50Hz[2] = {1.3422, 1.4399};
// coef[sampleFreqInd][order] for 60Hz
static float ahf_numerator_coef_60Hz[2][6] = {
    {0.9528, -1.3891, 0.9528, 0.8272, -0.7225, 0.0264},
    {0.5824, -1.0810, 0.5824, 1.0736, -2.0000, 1.0736}};
static float ahf_denominator_coef_60Hz[2][6] = {
    {1.0000, -1.3880, 0.9066, 1.0000, -0.9739, 0.2371},
    {1.0000, -1.8407, 0.9894, 1.0000, -1.8584, 0.9891}};
static float ahf_output_gain_coef_60Hz[2] = {1.3430, 1.4206};

/**
 * @brief LPF
 *
 */

float LPF_states[2];
float LPF_num[3];
float LPF_den[3];

void LPF_init(int sampleFreq) {
    LPF_states[0] = 0;
    LPF_states[1] = 0;
    // 2th order butterworth lowpass filter
    // cutoff frequency 150Hz
    if (sampleFreq == SAMPLE_FREQ_500HZ) {
        for (int i = 0; i < 3; i++) {
            LPF_num[i] = lpf_numerator_coef[0][i];
            LPF_den[i] = lpf_denominator_coef[0][i];
        }
    } else if (sampleFreq == SAMPLE_FREQ_1000HZ) {
        for (int i = 0; i < 3; i++) {
            LPF_num[i] = lpf_numerator_coef[1][i];
            LPF_den[i] = lpf_denominator_coef[1][i];
        }
    }
}
float LPF_update(float input) {
    float LPF_tmp =
        (input - LPF_den[1] * LPF_states[0] - LPF_den[2] * LPF_states[1]) /
        LPF_den[0];
    float LPF_output = LPF_num[0] * LPF_tmp + LPF_num[1] * LPF_states[0] +
                       LPF_num[2] * LPF_states[1];
    // save last states
    LPF_states[1] = LPF_states[0];
    LPF_states[0] = LPF_tmp;
    return LPF_output;
}
/**
 * @brief HPF
 *
 */
float HPF_states[2];
float HPF_num[3];
float HPF_den[3];

void HPF_init(int sampleFreq) {
    HPF_states[0] = 0;
    HPF_states[1] = 0;

    // 2th order butterworth
    // cutoff frequency 20Hz
    if (sampleFreq == SAMPLE_FREQ_500HZ) {
        for (int i = 0; i < 3; i++) {
            HPF_num[i] = hpf_numerator_coef[0][i];
            HPF_den[i] = hpf_denominator_coef[0][i];
        }
    } else if (sampleFreq == SAMPLE_FREQ_1000HZ) {
        for (int i = 0; i < 3; i++) {
            HPF_num[i] = hpf_numerator_coef[1][i];
            HPF_den[i] = hpf_denominator_coef[1][i];
        }
    }
}
float HPF_update(float HPF_input) {
    float HPF_tmp =
        (HPF_input - HPF_den[1] * HPF_states[0] - HPF_den[2] * HPF_states[1]) /
        HPF_den[0];

    float HPF_output = HPF_num[0] * HPF_tmp + HPF_num[1] * HPF_states[0] +
                       HPF_num[2] * HPF_states[1];

    // save last states
    HPF_states[1] = HPF_states[0];
    HPF_states[0] = HPF_tmp;
    return HPF_output;
}

/**
 * @brief FILTER_4th
 *
 */
float AHF_states[4];
float AHF_num[6];
float AHF_den[6];
float AHF_gain;

void AHF_init(int sampleFreq, int humFreq) {
    AHF_gain = 0;
    for (int i = 0; i < 4; i++) {
        AHF_states[i] = 0;
    }
    if (humFreq == NOTCH_FREQ_50HZ) {
        if (sampleFreq == SAMPLE_FREQ_500HZ) {
            for (int i = 0; i < 6; i++) {
                AHF_num[i] = ahf_numerator_coef_50Hz[0][i];
                AHF_den[i] = ahf_denominator_coef_50Hz[0][i];
            }
            AHF_gain = ahf_output_gain_coef_50Hz[0];
        } else if (sampleFreq == SAMPLE_FREQ_1000HZ) {
            for (int i = 0; i < 6; i++) {
                AHF_num[i] = ahf_numerator_coef_50Hz[1][i];
                AHF_den[i] = ahf_denominator_coef_50Hz[1][i];
            }
            AHF_gain = ahf_output_gain_coef_50Hz[1];
        }
    } else if (humFreq == NOTCH_FREQ_60HZ) {
        if (sampleFreq == SAMPLE_FREQ_500HZ) {
            for (int i = 0; i < 6; i++) {
                AHF_num[i] = ahf_numerator_coef_60Hz[0][i];
                AHF_den[i] = ahf_denominator_coef_60Hz[0][i];
            }
            AHF_gain = ahf_output_gain_coef_60Hz[0];
        } else if (sampleFreq == SAMPLE_FREQ_1000HZ) {
            for (int i = 0; i < 6; i++) {
                AHF_num[i] = ahf_numerator_coef_60Hz[1][i];
                AHF_den[i] = ahf_denominator_coef_60Hz[1][i];
            }
            AHF_gain = ahf_output_gain_coef_60Hz[1];
        }
    }
}

float AHF_update(float AHF_input) {
    float AHF_output;
    float AHF_stageIn;
    float AHF_stageOut;

    AHF_stageOut = AHF_num[0] * AHF_input + AHF_states[0];
    AHF_states[0] =
        (AHF_num[1] * AHF_input + AHF_states[1]) - AHF_den[1] * AHF_stageOut;
    AHF_states[1] = AHF_num[2] * AHF_input - AHF_den[2] * AHF_stageOut;
    AHF_stageIn   = AHF_stageOut;
    AHF_stageOut  = AHF_num[3] * AHF_stageOut + AHF_states[2];
    AHF_states[2] =
        (AHF_num[4] * AHF_stageIn + AHF_states[3]) - AHF_den[4] * AHF_stageOut;
    AHF_states[3] = AHF_num[5] * AHF_stageIn - AHF_den[5] * AHF_stageOut;

    AHF_output = AHF_gain * AHF_stageOut;

    return AHF_output;
}



/**
 * @brief EMGFilters
 *
 */
SAMPLE_FREQUENCY m_sampleFreq;
NOTCH_FREQUENCY  m_notchFreq;
int             m_bypassEnabled;
int             m_notchFilterEnabled;
int             m_lowpassFilterEnabled;
int             m_highpassFilterEnabled;

void EMGFilters_init(SAMPLE_FREQUENCY sampleFreq,
                     NOTCH_FREQUENCY  notchFreq,
                     int             enableNotchFilter,
                     int             enableLowpassFilter,
                     int             enableHighpassFilter) {
    m_sampleFreq    = sampleFreq;
    m_notchFreq     = notchFreq;
    m_bypassEnabled = true;

    if (((sampleFreq == SAMPLE_FREQ_500HZ) ||
         (sampleFreq == SAMPLE_FREQ_1000HZ)) &&
        ((notchFreq == NOTCH_FREQ_50HZ) || (notchFreq == NOTCH_FREQ_60HZ))) {
        m_bypassEnabled = false;
    }

    LPF_init(m_sampleFreq);
    HPF_init(m_sampleFreq);
    AHF_init(m_sampleFreq, m_notchFreq);

    m_notchFilterEnabled    = enableNotchFilter;
    m_lowpassFilterEnabled  = enableLowpassFilter;
    m_highpassFilterEnabled = enableHighpassFilter;
}


int EMGFilters_update(int EMGFilters_inputValue) {
    int EMGFilters_output = 0;
    if (m_bypassEnabled) {
        return EMGFilters_output = EMGFilters_inputValue;
    }

    // first notch filter
    if (m_notchFilterEnabled) {
        // output = NTF.update(EMGFilters_inputValue);
        EMGFilters_output = AHF_update(EMGFilters_inputValue);
    } else {
        // notch filter bypass
        EMGFilters_output = EMGFilters_inputValue;
    }

    // second low pass filter
    if (m_lowpassFilterEnabled) {
        EMGFilters_output = LPF_update(EMGFilters_output);
    }

    // third high pass filter
    if (m_highpassFilterEnabled) {
        EMGFilters_output = HPF_update(EMGFilters_output);
    }

    return EMGFilters_output;
}





